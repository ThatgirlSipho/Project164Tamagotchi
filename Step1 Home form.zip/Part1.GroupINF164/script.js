var changeFontStyle = function (font) {
    document.getElementById(
        "body").style.fontFamily
                = font.value;
}


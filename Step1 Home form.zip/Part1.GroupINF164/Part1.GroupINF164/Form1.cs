﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Part1.GroupINF164
{
    public partial class Form1 : Form
    {
        WindowsMediaPlayer player = new WindowsMediaPlayer();

        public Form1()
        {
            InitializeComponent();
            player.URL = "C:\\Users\\sunev\\Documents\\2022\\Semester 2\\INF 164\\Part1.GroupINF164\\shrek.wav";
            player.settings.setMode("loop", true);
         
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnInstructions_Click(object sender, EventArgs e)
        { //Read instructions from file
            string path = @"C:\Users\sunev\Documents\2022\Semester 2\INF 164\Part1.GroupINF164\Instructions.txt";
            StreamReader read = new StreamReader(File.OpenRead(path));
            MessageBox.Show(read.ReadToEnd());
            read.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {  // Close form
            this.Close();
        }

        private void btnPlayMusic_Click(object sender, EventArgs e)
        {
            //    axWindowsMediaPlayer1.URL = @"C:\Users\sunev\Documents\2022\Semester 2\INF 164\Part1.GroupINF164\shrek.wav";
            //    axWindowsMediaPlayer1.currentPlaylist = axWindowsMediaPlayer1.mediaCollection.getByName("shrek.wav");
            player.controls.play();
        }

        private void btnStopMusic_Click(object sender, EventArgs e)
        {
            player.controls.stop();
        }
    }
}
